#!/bin/bash
echo "RUN AS ROOT BLIAT"
git clone https://github.com/GrapheneOS/hardened_malloc.git
cd hardened_malloc
make test
cp out/libhard* /usr/lib
cp run_with_hardened_malloc.sh /usr/bin 
