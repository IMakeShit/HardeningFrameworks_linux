#!/bin/bash

export LD_PRELOAD+="/usr/lib/libhardened_malloc.so"
exec "$@"
