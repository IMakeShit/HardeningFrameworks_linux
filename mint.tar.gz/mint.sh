
# Функция для изменения /etc/fstab
update_fstab() {
    # Создание резервной копии fstab
    sudo cp /etc/fstab /etc/fstab.bak
    # Удаление существующих строк с логами
    sudo sed -i '//var/log/d' /etc/fstab
    # Добавление строк для монтирования логов в tmpfs
    sudo echo "tmpfs /var/log tmpfs size=100M,noexec,nosuid 0 0" >> /etc/fstab
}



echo "RUN AS ROOT!!!!!!!!!!!!!"
sudo apt purge telnet -y
sudo apt update
sudo apt install macchanger curl rofi zenity apt-transport-https -y

sudo curl --tlsv1.3 --output /usr/share/keyrings/derivative.asc --url https://www.whonix.org/keys/derivative.asc 

selected=$(echo -e "ClearNet\nClearnet via tor\nTor" | rofi -dmenu -p "Privacy 1 |How connect to Whonix repo?")

case $selected in
    "ClearNet")
        sudo echo "deb [signed-by=/usr/share/keyrings/derivative.asc] https://deb.whonix.org bookworm main contrib non-free" | sudo tee /etc/apt/sources.list.d/whonix.list
        ;;
    "Clearnet via tor")
	sudo apt install apt-transport-tor -y
        sudo echo "deb [signed-by=/usr/share/keyrings/derivative.asc] tor+https://deb.whonix.org bookworm main contrib non-free" | sudo tee /etc/apt/sources.list.d/whonix.list
	;;
    "Tor")
        sudo apt install apt-transport-tor -y
	sudo echo "deb [signed-by=/usr/share/keyrings/derivative.asc] tor+http://deb.dds6qkxpwdeubwucdiaord2xgbbeyds25rbsgr73tbfpqpt4a6vjwsyd.onion bookworm main contrib non-free" | sudo tee /etc/apt/sources.list.d/whonix.list
	;;
esac

sudo curl --tlsv1.3 --output /usr/share/keyrings/kicksecure.asc --url https://www.kicksecure.com/keys/derivative.asc 

selected=$(echo -e "ClearNet\nClearnet via tor\nTor" | rofi -dmenu -p "Privacy 1.1 | How connect to KickSecure repo?")

case $selected in
    "ClearNet")
		echo "deb [signed-by=/usr/share/keyrings/kicksecure.asc] https://deb.kicksecure.com bookworm main contrib non-free" | sudo tee /etc/apt/sources.list.d/kicksecure.list
        ;;
    "Clearnet via tor")
		sudo apt install apt-transport-tor -y
        sudo echo "deb [signed-by=/usr/share/keyrings/kicksecure.asc] tor+https://deb.kicksecure.com bookworm main contrib non-free" | sudo tee /etc/apt/sources.list.d/kicksecure.list
	;;
    "Tor")
        sudo apt install apt-transport-tor -y
		sudo echo "deb [signed-by= /usr/share/keyrings/kicksecure.asc] tor+http://deb.w5j6stm77zs6652pgsij4awcjeel3eco7kvipheu6mtr623eyyehj4yd.onion bookworm main contrib non-free" | sudo tee /etc/apt/sources.list.d/kicksecure.list
	;;
esac

sudo apt update
sudo apt install kloak apparmor-profile-utils apparmor-profiles apparmor-profiles-extra -y

selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Privacy 2 | Install a Anon Apps config(UTC time and other...) ?")
case $selected in
    "Yes")
		sudo apt install anon-apps-config -y
        ;;
    "No")
        ;;
esac



#ThunderBird Hardening
selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Security 1 | Install AppAmor Profile for thunderbird?")
case $selected in
    "Yes")
		sudo apt install apparmor-profile-thunderbird -y
        ;;
    "No")
        ;;
esac
#HexChat Hardening
selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Security 1.1 | Install AppAmor Profile for HexChat?")
case $selected in
    "Yes")
		sudo apt install apparmor-profile-hexchat -y
        ;;
    "No")
        ;;
esac
#Tor BRowser Hardening
selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Security 1.2 | Install AppAmor Profile for TorBrowser?")
case $selected in
    "Yes")
		sudo apt install apparmor-profile-torbrowser -y
        ;;
    "No")
        ;;
esac

selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Security 2 | Install some Tor security tweaks from Whonix gateway?")
case $selected in
    "Yes")
		sudo cp configs/tor_tweaks/anonymizer-config-gateway.conf /etc/sysctl.d/
        ;;
    "No")
        ;;
esac

selected=$(echo -e "Install tweaks from Runtime-Hardening package\nInstall tweaks by script author\nNo" | rofi -dmenu -p "Security 2.1 | (sysctl,kernel and grub tweaks)")
case $selected in
    "Install tweaks from Runtime-Hardening package")
    	sudo apt install hardening-runtime -y
        ;;
    "Install tweaks by script author")
		sudo cp configs/grub/01_hardening.cfg /etc/default/grub.d/
		sudo cp configs/sysctl/10-hardening.conf /usr/lib/sysctl.d/
        sudo rm /usr/lib/sysctl.d/50-mint.conf
    	;;
    "No")
        ;;
esac

selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Security 2.2 | Install security-misc?")
case $selected in
    "Yes")
    	sudo apt install security-misc -y
        ;;
    "No")
        ;;
esac

zenity --info --text="Внимание:Дальше вам будет предложено установить ram-wipe.Эта модификация initrd позволит защититься от Cold Boot атаки, но придётся установить другую систему сборки initrd что в худщем случае может сделать систему не загружаемой.Думайте"
selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Anti-forensic 1 |Install Cold boot attack protect? ?")
case $selected in
    "Yes")
		sudo apt install ram-wipe dracut -y
        ;;
    "No")
        ;;
esac
 
selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Anti-forensic 1.1 | Enable encrypted swap?(need a free partion)")
case $selected in
    "Yes")
    	sudo sed -i '/swapd' /etc/fstab
		sudo echo "swap $(zenity --entry --text="Enter a partion with swap:") /dev/urandom swap,cipher=aes-xts-plain64,size=$(zenity --entry --text="size of swap:"),sector-size" >> /etc/fstab
        ;;
    "No")
        ;;
esac

selected=$(echo -e "Yes\nNo" | rofi -dmenu -p "Anti-forensic 1.2 | kernel tweaks for disabling logs")
case $selected in
    "Yes")
    	sudo cp configs/grub/01_anti_forensic.cfg /etc/default/grub.d/
        ;;
    "No")
        ;;
esac

zenity --info --text="В следующем окне вам дадут выбор переводить ли логи в tmpfs(они не будут сохранятся на диск и при перезагрузке как ничего и не было) и это может помещать криминалистическому анализу систему и повысить скорость работы НО это может сломать работу некоторых программ а также вызвать проблемы с поиском неисправностей так как логи не будут оставаться в системе.Выбирайте с умом!(Можно это убрать в любой момент но всё же)"
selected=$(echo -e "Переместить логи в tmpfs\nНет" | rofi -dmenu -p "Anti-forensic 1.3 | Переместить логи системы в tmpfs?")
# Проверка, выбрана ли опция
if [[ -z "$selected" ]]; then
    break
fi
case "$selected" in
	"Переместить логи в tmpfs")
        update_fstab
        sudo systemctl daemon-reload
        echo "Изменения внесены в /etc/fstab. Перементируем раздеы,,." & sudo mount -a
        ;;
    "Нет")
        ;;
esac

sudo update-grub
